<html>
<body>
	<p><label>Tên:</label> <?php echo $name ?></p>
    <p><label>Email:</label> <?php echo $email ?></p>
    <p><label>Nội dung:</label> <?php echo $content ?></p>
</body>
</html>