		<footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    
                </nav>
                <p class="copyright pull-right">
                    © 2018 <a href="http://akanice.com">poh.vn</a> - Thai giáo - 280 ngày yêu thương
                </p>
            </div>
        </footer>
	</div>
</div>