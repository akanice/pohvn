	<section class="newsgrid">
		<div class="container">
			<div class="row clearfix">
				<div class="col-md-12 center" style="padding: 50px 0">
					<h3 class="">Xin lỗi, trang bạn yêu cầu không được tìm thấy</h3><br>
					<a href="<?=site_url()?>" class="btn btn-more">Quay về Trang chủ</a>
				</div>
			</div>
		</div>
	</section>