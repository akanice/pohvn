	<section id="#slider" class="featured-area featured-style-26 penci-featured-loaded">
		<div class="container">
			<div class="wrapper-item wrapper-item-classess">
				<div class="penci-item-mag penci-item-1"> <a class="penci-image-holder owl-lazy" href="#" title="Travel Guide Europe’s hidden coasts: the Deep Mani, Greece" style="background-image: url('/assets/img/sample_image-2.jpg'); opacity: 1;"></a>
					<div class="penci-slide-overlay penci-slider6-overlay"> <a class="overlay-link" href="#"></a>
						<div class="penci-mag-featured-content">
							<div class="feat-text slider-hide-date">
								<div class="cat featured-cat"><a class="penci-cat-name" href="#" rel="category tag">Editor's Picks</a><a class="penci-cat-name" href="#" rel="category tag">Travel</a></div>
								<h3><a title="Travel Guide Europe’s hidden coasts: the Deep Mani, Greece" href="#">Travel Guide Europe’s hidden coasts: the Deep Mani, Greece</a></h3>
							</div>
						</div>
					</div>
				</div>
				<div class="penci-item-mag penci-item-2"> <a class="penci-image-holder owl-lazy" href="#" title="The Head of Design at Ikea on “Sampling” Versus Stealing in Fashion" style="background-image: url('/assets/img/sample_image-2.jpg'); opacity: 1;"></a>
					<div class="penci-slide-overlay penci-slider6-overlay"> <a class="overlay-link" href="#"></a>
						<div class="penci-mag-featured-content">
							<div class="feat-text slider-hide-date">
								<h3><a title="The Head of Design at Ikea on “Sampling” Versus Stealing in Fashion" href="#">The Head of Design at Ikea on “Sampling” Versus Stealing in Fashion</a></h3>
							</div>
						</div>
					</div>
				</div>
				<div class="penci-item-mag penci-item-3"> <a class="penci-image-holder owl-lazy" href="#" title="5 Interview Questions You Should Always Be Prepared To Answer" style="background-image: url('/assets/img/sample_image-2.jpg'); opacity: 1;"></a>
					<div class="penci-slide-overlay penci-slider6-overlay"> <a class="overlay-link" href="#"></a>
						<div class="penci-mag-featured-content">
							<div class="feat-text slider-hide-date">
								<h3><a title="5 Interview Questions You Should Always Be Prepared To Answer" href="#">5 Interview Questions You Should Always Be Prepared To Answer</a></h3>
							</div>
						</div>
					</div>
				</div>
				<div class="penci-item-mag penci-item-4"> <a class="penci-image-holder owl-lazy" href="#" title="The 11 Most Beautiful Beach Towns In The World" style="background-image: url('/assets/img/sample_image-2.jpg'); opacity: 1;"></a>
					<div class="penci-slide-overlay penci-slider6-overlay"> <a class="overlay-link" href="#"></a>
						<div class="penci-mag-featured-content">
							<div class="feat-text slider-hide-date">
								<h3><a title="The 11 Most Beautiful Beach Towns In The World" href="#">The 11 Most Beautiful Beach Towns In The World</a></h3>
							</div>
						</div>
					</div>
				</div>
				<div class="penci-item-mag penci-item-0"> <a class="penci-image-holder owl-lazy" href="#" title="25 Reasons to Visit Maryland’s Eastern Shore Now" style="background-image: url('/assets/img/sample_image-2.jpg'); opacity: 1;"></a>
					<div class="penci-slide-overlay penci-slider6-overlay"> <a class="overlay-link" href="#"></a>
						<div class="penci-mag-featured-content">
							<div class="feat-text slider-hide-date">
								<h3><a title="25 Reasons to Visit Maryland’s Eastern Shore Now" href="#">25 Reasons to Visit Maryland’s Eastern Shore Now</a></h3>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<div class="section-block">
		<div class="container">
			<div class="row">
				<div class="col-md-12" id="main">
				
				</div>
			</div>
		</div>
	</div>
