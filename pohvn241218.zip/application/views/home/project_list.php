	<section class="section-block projects-page">
		<div class="container">
			<div class="row clearfix">
				<div class="col-md-12">
					<h2 class="box-header center">Các dự án của chúng tôi</h2>
					<div class="projects-list clearfix">
						<div class="col-sm-4">
							<a href="#" title="">
								<img src="/assets/img/full-screen-image-4.jpg" alt="" class="img-holder thumb">
							</a>
							<div class="pj-content center">
								<h3>Du an Hoa Ky</h3>
								<div class="description">
									Lorem ipsum dolor sit amet...
								</div>
								<div class="center">
									<a href="#" class="btn btn-more">Chi tiết</a>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<a href="#" title="">
								<img src="/assets/img/full-screen-image-2.jpg" alt="" class="img-holder thumb">
							</a>
							<div class="pj-content center">
								<h3>Du an Hoa Ky</h3>
								<div class="description">
									Lorem ipsum dolor sit amet...
								</div>
								<div class="center">
									<a href="#" class="btn btn-more">Chi tiết</a>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<a href="#" title="">
								<img src="/assets/img/full-screen-image-1.jpg" alt="" class="img-holder thumb">
							</a>
							<div class="pj-content center">
								<h3>Du an Hoa Ky</h3>
								<div class="description">
									Lorem ipsum dolor sit amet...
								</div>
								<div class="center">
									<a href="#" class="btn btn-more">Chi tiết</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>