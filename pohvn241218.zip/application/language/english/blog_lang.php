<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

//Blog list
$lang['home'] = 'Homepage';
$lang['noposthere'] = 'Updating';
$lang['postday'] = 'Posted on';
$lang['category'] = 'Category';
$lang['newestpost'] = 'Latest Post';

//Blog detail
$lang['relatedpost'] = 'Relevant Post';
$lang['noposthere'] = 'Updating';
$lang['postday'] = 'Posted on';
$lang['category'] = 'Category';
$lang['newestpost'] = 'Latest Post';
$lang['relatetour'] = 'Relevant Tour';




