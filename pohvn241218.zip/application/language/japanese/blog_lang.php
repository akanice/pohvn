<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

//Blog list
$lang['home'] = 'Trang chủ';
$lang['noposthere'] = 'Chưa có bài viết nào trong mục này';
$lang['postday'] = 'Đăng ngày';
$lang['category'] = 'Danh mục';
$lang['newestpost'] = 'Bài viết mới nhất';

//Blog detail
$lang['relatedpost'] = 'Bài viết liên quan';
$lang['noposthere'] = 'Chưa có bài viết nào trong mục này';
$lang['postday'] = 'Đăng ngày';
$lang['category'] = 'Danh mục';
$lang['newestpost'] = 'Bài viết mới nhất';




